import React from 'react';
import './Dummy.scss';

const Dummy = () => {
    return (
        <div className='overlay'>

            <div className="loadingio-spinner-gear-nkmshbgj3o">
                <div className="ldio-qye8wo9tsad">
                    <div>
                        <div />
                        <div />
                        <div />
                        <div />
                        <div />
                        <div />
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Dummy;
