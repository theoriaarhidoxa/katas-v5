import './App.scss';
import React, {useState, useRef} from "react";
import axios from "axios";
import Dummy from "./helpers/Dummy";
import List from "./helpers/List";



// для fileloader: Кто-то должен это сделать, заявил автор этого ролика

function App() {
    const baseUrl = `https://www.codewars.com/api/v1/users/`;
    const [savedUserData, setSavedUserData] = useState({});
    const [sourceUserPages, setSourceUserPages] = useState(null);
    const [targetUserPages, setTargetUserPages] = useState(null);

    const [sourceUser, setSourceUser] = useState('');
    const [targetUser, setTargetUser] = useState('');

    const [list, setList] = useState([]);
    const [category, setCategory] = useState('completed');

    const [sourceUserStatusSuccess, setSourceUserStatusSuccess] = useState(false);
    const [targetUserStatusSuccess, setTargetUserStatusSuccess] = useState(false);
    const [sourceUserStatusFail, setSourceUserStatusFail] = useState(false);
    const [targetUserStatusFail, setTargetUserStatusFail] = useState(false);

    const [loading, setLoading] = useState(false);
    const [searchActive, setSearchActive] = useState(false);
    const [nonJsThrown, setNonJsThrown] = useState(true);

    const tooltip = useRef();

    const handleUserInput = (type, val) => {
        type === 'source' ? setSourceUserStatusSuccess(false) : setTargetUserStatusSuccess(false);
        type === 'source' ? setSourceUserStatusFail(false) : setTargetUserStatusFail(false);
        type === 'source' ? setSourceUser(val) : setTargetUser(val);
    };

    const handleUserCheck = async (type, username) => {
        try {
            const res = await axios.get(`${baseUrl}${username}`);
            type === 'source' ? setSourceUserStatusSuccess(true) : setTargetUserStatusSuccess(true);
            type === 'source' ? setSourceUserStatusFail(false) : setTargetUserStatusFail(false);
            type === 'source' ? setSourceUserPages(Math.ceil(res.data.codeChallenges.totalCompleted / 200)) : setTargetUserPages(Math.ceil(res.data.codeChallenges.totalCompleted / 200));
        } catch (e) {
            type === 'source' ? setSourceUserStatusFail(true) : setTargetUserStatusFail(true);
            type === 'source' ? setSourceUserStatusSuccess(false) : setTargetUserStatusSuccess(false);
        }
    };

    const handleKataFetch = async (username, pageSize, isAuth) => {
        setLoading(true);
        let total = [];

        if(isAuth) {
            const res = await axios.get(`https://www.codewars.com/api/v1/users/${username}/code-challenges/authored`);
            total = total.concat(res.data);
        } else {
            while (pageSize >= 0) {
                const chunk = await axios.get(`${baseUrl}${username}/code-challenges/completed?page=${pageSize}`);
                total = total.concat(chunk.data);
                pageSize--;
            }
        }

        total = [].concat(...total.map(el => el.data)).filter(el => {
            if (el) {
                if (el.completedLanguages) {
                    return nonJsThrown ? el.completedLanguages.includes('javascript') : el;
                } else if (el.languages) {
                    return nonJsThrown ? el.languages.includes('javascript') : el;
                } else {
                    return el;
                }
            }
        });
        setLoading(false);
        return total;
    };

    const handleFormSubmit = async e => {
        e.preventDefault();
        const targetKey = `${targetUser}_${category}`;
        const set1 = sourceUser in savedUserData ? savedUserData[sourceUser] : await handleKataFetch(sourceUser, sourceUserPages);
        const set2 = targetKey in savedUserData ? savedUserData[targetKey] : await handleKataFetch(targetUser, targetUserPages, category === 'authored');
        setSavedUserData({...savedUserData, [sourceUser]: set1, [targetKey]: set2});

        const names = set1.map(el => el.name);
        let found = set2.filter(kata => kata.name && names.indexOf(kata.name) < 0);
        let duplicates = found.map(el => el.id);
        duplicates = duplicates.filter((el, i, arr) => arr.indexOf(el) < arr.lastIndexOf(el));
        found = found.filter(el => duplicates.indexOf(el.id) < 0);
        setList(found);
        setSearchActive(true);
    };

    const handleCheckboxProcessing = () => {
        setNonJsThrown(!nonJsThrown);
        const cleanedUserData = {};
        for (const key in savedUserData) {
            if (savedUserData.hasOwnProperty(key)) {
                if (key.startsWith(sourceUser) || key.startsWith(targetUser)) {
                    continue;
                }
                cleanedUserData[key] = savedUserData[key];
            }
        }
        setSavedUserData(cleanedUserData);
    };

    const handleTooltipVisibility = e => {
        tooltip.current.style.left = (e.screenX + 10) + 'px';
        tooltip.current.style.top = (e.screenY - 50) + 'px';
    };

    const handleCategoryChange = e => {
        setCategory(e.target.value);
    };

    if (loading) {
        return <Dummy/>
    }

    return (
        <div className="wrapper">
            <p>И снова ката, на этот раз поиск. В списке user2 ищется то, чего нет у user1. Например, если нужно найти у кого-то задачу, которую сам пока не решил.</p><br />
            <p>Реализован простейший механизм кеширования, так что при повторном запросе к одним и&nbsp;тем же пользователям есть шанс больше не увидеть лоадер.</p>

            <form className='wrapper__form' onSubmit={handleFormSubmit}>
                <div className='wrapper__form-block'>
                    <input className={sourceUserStatusSuccess ? 'validInput' : sourceUserStatusFail ? 'invalidInput' : ''} type='text' placeholder='user1: ваш ник на CodeWars' value={sourceUser} onChange={e => handleUserInput('source', e.target.value)} />
                    <button disabled={sourceUserStatusSuccess} className='btn' type='button' onClick={() => handleUserCheck('source', sourceUser)}>{sourceUserStatusSuccess ? 'Проверено' : 'Проверить'}</button>
                    {sourceUserStatusFail && <p>Пользователь {sourceUser} не найден.</p>}
               </div>

                <div className='wrapper__form-block'>
                    <input className={targetUserStatusSuccess ? 'validInput' : targetUserStatusFail ? 'invalidInput' : ''} type='text' placeholder='user2: у кого будем искать?' value={targetUser} onChange={e => handleUserInput('target', e.target.value)} />
                    <button disabled={targetUserStatusSuccess} className='btn' type='button' onClick={() => handleUserCheck('target', targetUser)}>{targetUserStatusSuccess ? 'Проверено' : 'Проверить'}</button>
                    {targetUserStatusFail && <p>Пользователь {targetUser} не найден.</p>}
                </div>

               {sourceUser && targetUser && sourceUser === targetUser && <div className='wrapper__form-warning'><p>Имена пользователей совпадают, поиск не будет продолжен!</p></div>}

                <div className='wrapper__form-searchOptions'>

                    <div className={nonJsThrown ? 'toggleViewedBlock active' : 'toggleViewedBlock'}
                         onClick={handleCheckboxProcessing}>
                        <span><i/></span> <p>Исключить ката без javascript</p>
                    </div>

                    {/*<label><input type='checkbox' checked={nonJsThrown} onChange={handleCheckboxProcessing} /> <span>Исключить ката без javascript</span></label>*/}
                    <p onMouseMove={handleTooltipVisibility}>Категория <span className='tooltip' ref={tooltip}>У пользователя есть два практически не пересекающихся списка задач: авторские и решённые.<br /> При обращении к API для их получения используются разные запросы.</span></p>
                    <select value={category} onChange={handleCategoryChange}>
                        <option value={'completed'}>Искать в решённых</option>
                        <option value={'authored'}>Искать в авторских</option>
                    </select>
                    <button className='btn red' type='submit' disabled={!sourceUserStatusSuccess || !targetUserStatusSuccess || (sourceUser === targetUser)}>Поиск</button>
                </div>
            </form>

            <div className='wrapper__output'>
                {searchActive && (list.length > 0 ? <p>Найдено: <b>{list.length}</b>.</p> : <p>Ничего не найдено.</p>)}
                <div>
                    <List list={list} />
                </div>
            </div>

        </div>
    );
}

export default App;
